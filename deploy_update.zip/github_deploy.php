<?php
if ($_GET["token"] !== "Lanuadecoco43_GHAction") exit;
$data = file_get_contents("php://input");
file_put_contents("update.zip", $data);
exec("unzip -o update.zip", $out, $ret);
if ($ret === 0) { echo "OK"; } else { echo "UNZIP ERR $ret"; }
unlink("update.zip");
?>
